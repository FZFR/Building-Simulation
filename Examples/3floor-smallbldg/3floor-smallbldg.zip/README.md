
```
Area = L x W = xx m²
```

L: 7 m  
W: 6 m

Height:  
2nd floor: 3.3m  
3rd floor: 3m

* 1st condition:  
  - 2nd floor  
  **office (Open Office)**
  - 3rd floor   
  **studio**  
  Heat source: camera lighting around 500 watts, needs to convert to W/m²
  ```
  Convert to W/m²= Watts / Area
  ```  
  5peoples in the room, needs to convert to Density per square meter   
  ```
  Population Density = Number of People/Land Area.
  ```
* 2nd condition:  
  - 2nd and 3rd floor: Multifaith space: 1.3ppl/m²
  
the rest data provided by Honeybee ListZonePrograms and Honeybee GetEPLoads (Office:OpenOffice and Office:IT_Room)

all weather data belongs here:  
[Jakarta Downtown(epw)](https://github.com/Fazzafr/Building-Simulation/blob/master/Weather-Data/epw/Jakarta_Downtown.epw)  
[Jakarta Downtown(ddy)](https://github.com/Fazzafr/Building-Simulation/blob/master/Weather-Data/ddy/Jakarta_Downtown.ddy)
